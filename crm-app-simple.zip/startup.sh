#!/bin/bash

# Create writable data directory
mkdir -p /tmp/data
chmod 777 /tmp/data

# Set environment variables if not already set
export DATABASE_URL=${DATABASE_URL:-"sqlite:////tmp/data/crm.db"}
export SECRET_KEY=${SECRET_KEY:-"development-key-change-in-production"}
export FLASK_ENV=${FLASK_ENV:-"production"}

echo "Starting CRM application..."
echo "DATABASE_URL: $DATABASE_URL"

# Start the application directly - dependencies should already be installed
exec gunicorn --bind=0.0.0.0:8000 --timeout 600 --workers 1 --preload app:app
