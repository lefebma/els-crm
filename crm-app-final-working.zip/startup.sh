#!/bin/bash

# Set environment variables
export SECRET_KEY=${SECRET_KEY:-"azure-production-secret-2025"}
export FLASK_ENV=${FLASK_ENV:-"production"}

echo "Starting CRM application with gunicorn config..."

# Start the application using the config file
exec gunicorn app:app -c gunicorn.conf.py
