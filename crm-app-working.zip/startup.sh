#!/bin/bash

# Create instance directory for SQLite database
mkdir -p instance
chmod 755 instance

# Set environment variables
export SECRET_KEY=${SECRET_KEY:-"azure-production-secret-2025"}
export FLASK_ENV=${FLASK_ENV:-"production"}

echo "Starting CRM application..."
echo "Working directory: $(pwd)"
echo "Instance directory exists: $(ls -la instance/ 2>/dev/null || echo 'No')"

# Start the application
exec gunicorn --bind=0.0.0.0:8000 --timeout 600 --workers 1 --preload app:app
