#!/bin/bash

# Create writable data directory
mkdir -p /tmp/data
chmod 777 /tmp/data

# Set environment variables if not already set
export DATABASE_URL=${DATABASE_URL:-"sqlite:////tmp/data/crm.db"}
export SECRET_KEY=${SECRET_KEY:-"development-key-change-in-production"}
export FLASK_ENV=${FLASK_ENV:-"production"}

# Install dependencies
python -m pip install --upgrade pip
pip install -r requirements.txt

# Initialize database tables
python -c "
from app import app
from database import db
import os
with app.app_context():
    db.create_all()
    print('Database tables created successfully')
"

# Start the application
exec gunicorn --bind=0.0.0.0:8000 --timeout 600 app:app
